package saffchen.command;

public interface Exit {
    void doExit() throws Exception;
}
