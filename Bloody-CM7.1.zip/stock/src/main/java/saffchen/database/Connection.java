package saffchen.database;

public interface Connection {

}
