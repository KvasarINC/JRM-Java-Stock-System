package saffchen.reports;

interface Report {
    void generateReport() throws Exception;
}
